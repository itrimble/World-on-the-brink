```typescript
// src/renderer/services/CrisisService.ts
import { Crisis, CrisisStage } from '../../shared/types/crisis';
import { store } from '../store';
import { adjustPrestige } from '../features/player/playerSlice';
import { 
  addCrisis, 
  updateCrisis, 
  removeCrisis, 
  adjustTensionLevel 
} from '../features/game/worldSlice';
import { addHistoricalEvent } from '../features/game/worldSlice';
import { audioService } from './AudioService';

class CrisisService {
  private escalationLadder: CrisisStage[] = [
    'question',
    'challenge',
    'diplomatic-crisis',
    'defcon-4',
    'defcon-3',
    'defcon-2',
    'defcon-1'
  ];

  /**
   * Start a new crisis
   */
  public initiateCrisis(
    initiator: string,
    respondent: string,
    triggerPolicyId: string,
    involvedCountries: string[],
    crisisType: Crisis['type']
  ): Crisis {
    const crisisId = `crisis_${Date.now()}`;
    
    // Create crisis object
    const crisis: Crisis = {
      id: crisisId,
      type: crisisType,
      involvedCountries,
      initiator,
      respondent,
      triggerPolicy: { id: triggerPolicyId } as any, // Would be properly typed in real implementation
      currentStage: 'question',
      escalationRisk: this.calculateEscalationRisk(initiator, respondent, involvedCountries),
      turnStarted: store.getState().game.currentTurn
    };
    
    // Add to store
    store.dispatch(addCrisis(crisis));
    
    // Play crisis sound
    audioService.playSound('crisis_start');
    
    return crisis;
  }

  /**
   * Escalate a crisis to the next stage
   */
  public escalateCrisis(crisisId: string): Crisis | null {
    const state = store.getState();
    const crisis = state.world.currentCrises.find(c => c.id === crisisId);
    
    if (!crisis) {
      console.error(`Crisis not found: ${crisisId}`);
      return null;
    }
    
    // Find current stage index
    const currentIndex = this.escalationLadder.indexOf(crisis.currentStage);
    if (currentIndex === -1 || currentIndex >= this.escalationLadder.length - 1) {
      console.error(`Invalid crisis stage or already at maximum: ${crisis.currentStage}`);
      return null;
    }
    
    // Get next stage
    const nextStage = this.escalationLadder[currentIndex + 1];
    
    // Update crisis
    const updatedCrisis: Crisis = {
      ...crisis,
      currentStage: nextStage
    };
    
    store.dispatch(updateCrisis(updatedCrisis));
    
    // Increase global tension
    store.dispatch(adjustTensionLevel(5 + currentIndex * 3));
    
    // Check for accidental war if at high levels
    if (nextStage === 'defcon-3' || nextStage === 'defcon-2') {
      const tensionLevel = store.getState().world.tensionLevel;
      const accidentalWarRisk = this.calculateAccidentalWarRisk(tensionLevel, nextStage);
      
      if (Math.random() < accidentalWarRisk) {
        return this.triggerAccidentalWar(crisisId);
      }
    }
    
    // DEFCON 1 is nuclear war game over
    if (nextStage === 'defcon-1') {
      return this.triggerNuclearWar(crisisId);
    }
    
    // Play appropriate sound
    switch (nextStage) {
      case 'challenge':
        audioService.playSound('crisis_escalate_low');
        break;
      case 'diplomatic-crisis':
        audioService.playSound('crisis_escalate_medium');
        break;
      case 'defcon-4':
      case 'defcon-3':
      case 'defcon-2':
        audioService.playSound('crisis_escalate_high');
        break;
    }
    
    return updatedCrisis;
  }

  /**
   * Resolve a crisis with one side backing down
   */
  public resolveCrisis(crisisId: string, winnerFaction: 'usa' | 'ussr'): Crisis | null {
    const state = store.getState();
    const crisis = state.world.currentCrises.find(c => c.id === crisisId);
    
    if (!crisis) {
      console.error(`Crisis not found: ${crisisId}`);
      return null;
    }
    
    // Calculate prestige changes
    const prestigeValue = this.calculatePrestigeForCrisis(crisis);
    
    // Determine winner and loser
    const loserFaction = winnerFaction === 'usa' ? 'ussr' : 'usa';
    
    // Update crisis with resolution
    const resolvedCrisis: Crisis = {
      ...crisis,
      resolution: {
        winner: winnerFaction,
        loser: loserFaction,
        prestige: {
          [winnerFaction]: prestigeValue,
          [loserFaction]: -prestigeValue
        }
      }
    };
    
    // Update store
    store.dispatch(updateCrisis(resolvedCrisis));
    
    // Award prestige to winner, remove from loser
    store.dispatch(adjustPrestige(state.player.faction === winnerFaction ? prestigeValue : -prestigeValue));
    
    // Add to historical events
    store.dispatch(addHistoricalEvent({
      id: `event_crisis_${Date.now()}`,
      type: 'treaty',
      countries: crisis.involvedCountries,
      description: `${winnerFaction.toUpperCase()} prevailed in the ${this.getCrisisName(crisis)} crisis.`,
      turn: state.game.currentTurn
    }));
    
    // Reduce tension slightly
    store.dispatch(adjustTensionLevel(-10));
    
    // Play appropriate sound
    audioService.playSound('crisis_resolved');
    
    return resolvedCrisis;
  }

  /**
   * Trigger accidental nuclear war with a small probability
   */
  private triggerAccidentalWar(crisisId: string): Crisis | null {
    const state = store.getState();
    const crisis = state.world.currentCrises.find(c => c.id === crisisId);
    
    if (!crisis) return null;
    
    // Create a nuclear war crisis that's an escalation of the current one
    const nuclearCrisis: Crisis = {
      ...crisis,
      type: 'nuclear-threat',
      currentStage: 'defcon-1',
      resolution: {
        winner: 'none',
        loser: 'both',
        prestige: {
          usa: -1000,
          ussr: -1000
        }
      }
    };
    
    // Update store
    store.dispatch(updateCrisis(nuclearCrisis));
    
    // Add to historical events
    store.dispatch(addHistoricalEvent({
      id: `event_nuclear_war_${Date.now()}`,
      type: 'war',
      countries: ['usa', 'ussr', ...crisis.involvedCountries],
      description: 'Accidental nuclear war broke out during a tense standoff.',
      turn: state.game.currentTurn
    }));
    
    // Play appropriate sound
    audioService.playSound('nuclear_war');
    
    return nuclearCrisis;
  }

  /**
   * Trigger intentional nuclear war (DEFCON 1)
   */
  private triggerNuclearWar(crisisId: string): Crisis | null {
    const state = store.getState();
    const crisis = state.world.currentCrises.find(c => c.id === crisisId);
    
    if (!crisis) return null;
    
    // Create resolved nuclear war crisis
    const nuclearCrisis: Crisis = {
      ...crisis,
      type: 'nuclear-threat',
      currentStage: 'defcon-1',
      resolution: {
        winner: 'none',
        loser: 'both',
        prestige: {
          usa: -1000,
          ussr: -1000
        }
      }
    };
    
    // Update store
    store.dispatch(updateCrisis(nuclearCrisis));
    
    // Add to historical events
    store.dispatch(addHistoricalEvent({
      id: `event_nuclear_war_${Date.now()}`,
      type: 'war',
      countries: ['usa', 'ussr', ...crisis.involvedCountries],
      description: 'Nuclear war broke out as tensions reached DefCon 1.',
      turn: state.game.currentTurn
    }));
    
    // Play appropriate sound
    audioService.playSound('nuclear_war');
    
    return nuclearCrisis;
  }

  /**
   * Calculate how much prestige is at stake in a crisis
   */
  private calculatePrestigeForCrisis(crisis: Crisis): number {
    // Base prestige value based on crisis stage
    const stageIndex = this.escalationLadder.indexOf(crisis.currentStage);
    const basePrestige = 10 + stageIndex * 15;
    
    // Adjust based on countries involved
    const countryMultiplier = crisis.involvedCountries.length * 0.2 + 0.8;
    
    // Adjust based on crisis type
    let typeMultiplier = 1.0;
    switch (crisis.type) {
      case 'nuclear-threat':
        typeMultiplier = 2.0;
        break;
      case 'territorial-dispute':
        typeMultiplier = 1.5;
        break;
      case 'military-provocation':
        typeMultiplier = 1.3;
        break;
      case 'diplomatic-incident':
        typeMultiplier = 0.8;
        break;
    }
    
    // Calculate final prestige value
    return Math.round(basePrestige * countryMultiplier * typeMultiplier);
  }

  /**
   * Calculate risk of crisis escalation
   */
  private calculateEscalationRisk(initiator: string, respondent: string, involvedCountries: string[]): number {
    // This would be more complex in a real implementation
    return Math.random() * 0.5 + 0.2; // 20-70% baseline risk
  }

  /**
   * Calculate risk of accidental nuclear war
   */
  private calculateAccidentalWarRisk(tensionLevel: number, stage: CrisisStage): number {
    // Base risk depends on stage
    let baseRisk = 0;
    
    switch (stage) {
      case 'defcon-3':
        baseRisk = 0.02; // 2% chance
        break;
      case 'defcon-2':
        baseRisk = 0.05; // 5% chance
        break;
      default:
        return 0; // No chance at other stages
    }
    
    // Adjust based on global tension
    const tensionMultiplier = tensionLevel / 50; // 0.5-2x at 25-100 tension
    
    return baseRisk * tensionMultiplier;
  }

  /**
   * Get a descriptive name for a crisis
   */
  private getCrisisName(crisis: Crisis): string {
    // This would be more sophisticated in a real implementation
    // For now, just use the primary country name
    const primaryCountry = crisis.involvedCountries[0] || 'international';
    
    let typeName = '';
    switch (crisis.type) {
      case 'diplomatic-incident':
        typeName = 'diplomatic';
        break;
      case 'military-provocation':
        typeName = 'military';
        break;
      case 'territorial-dispute':
        typeName = 'territorial';
        break;
      case 'proxy-conflict':
        typeName = 'proxy';
        break;
      case 'nuclear-threat':
        typeName = 'nuclear';
        break;
    }
    
    return `${primaryCountry} ${typeName}`;
  }

  /**
   * Get a description of the current crisis stage for UI
   */
  public getCrisisStageDescription(stage: CrisisStage): string {
    switch (stage) {
      case 'question':
        return 'Diplomatic Inquiry';
      case 'challenge':
        return 'Formal Challenge';
      case 'diplomatic-crisis':
        return 'Public Diplomatic Crisis';
      case 'defcon-4':
        return 'Military Alert (DefCon 4)';
      case 'defcon-3':
        return 'High Alert (DefCon 3)';
      case 'defcon-2':
        return 'War Preparation (DefCon 2)';
      case 'defcon-1':
        return 'Nuclear War (DefCon 1)';
      default:
        return 'Unknown Stage';
    }
  }

  /**
   * Get the index of a crisis stage in the escalation ladder
   */
  public getCrisisStageIndex(stage: CrisisStage): number {
    return this.escalationLadder.indexOf(stage);
  }

  /**
   * Get the total number of stages in the escalation ladder
   */
  public getTotalCrisisStages(): number {
    return this.escalationLadder.length;
  }
}

// Export singleton instance
export const crisisService = new CrisisService();
```