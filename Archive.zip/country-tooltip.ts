```typescript
// src/renderer/components/map/CountryTooltip.tsx
import React from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';

interface CountryTooltipProps {
  countryId: string;
  x: number;
  y: number;
}

export const CountryTooltip: React.FC<CountryTooltipProps> = ({ countryId, x, y }) => {
  const country = useSelector((state: RootState) => state.world.countries[countryId]);
  const mapMode = useSelector((state: RootState) => state.ui.mapMode);
  
  if (!country) return null;
  
  const getTooltipContent = () => {
    switch (mapMode) {
      case 'political':
        return (
          <>
            <div className="font-bold">{country.government.type.charAt(0).toUpperCase() + country.government.type.slice(1)}</div>
            <div>Alignment: {country.government.alignment.charAt(0).toUpperCase() + country.government.alignment.slice(1)}</div>
          </>
        );
        
      case 'influence':
        return (
          <>
            <div>USA Influence: <span className="text-blue-400">{country.relations.usa}</span></div>
            <div>USSR Influence: <span className="text-red-400">{country.relations.ussr}</span></div>
          </>
        );
        
      case 'insurgency':
        return (
          <>
            <div>Insurgency Level: <span className={
              country.internal.insurgencyLevel < 10 ? 'text-green-400' :
              country.internal.insurgencyLevel < 30 ? 'text-yellow-400' :
              country.internal.insurgencyLevel < 60 ? 'text-orange-400' :
              'text-red-400'
            }>{country.internal.insurgencyLevel}%</span></div>
          </>
        );
        
      case 'coup':
        return (
          <>
            <div>Government Stability: <span className={
              country.government.stability > 80 ? 'text-green-400' :
              country.government.stability > 60 ? 'text-blue-400' :
              country.government.stability > 40 ? 'text-yellow-400' :
              country.government.stability > 20 ? 'text-orange-400' :
              'text-red-400'
            }>{country.government.stability}%</span></div>
            <div>Coup Risk: <span className={
              country.internal.coupRisk < 10 ? 'text-green-400' :
              country.internal.coupRisk < 30 ? 'text-yellow-400' :
              country.internal.coupRisk < 60 ? 'text-orange-400' :
              'text-red-400'
            }>{country.internal.coupRisk}%</span></div>
          </>
        );
        
      case 'economy':
        return (
          <>
            <div>GDP: ${country.economy.gdp.toLocaleString()} billion</div>
            <div>Growth: <span className={
              country.economy.growth > 3 ? 'text-green-400' :
              country.economy.growth > 0 ? 'text-blue-400' :
              'text-red-400'
            }>{country.economy.growth}%</span></div>
            <div>Development: {country.economy.development.charAt(0).toUpperCase() + country.economy.development.slice(1)}</div>
          </>
        );
        
      default:
        return null;
    }
  };
  
  // Position the tooltip relative to the mouse position
  const tooltipStyle: React.CSSProperties = {
    left: x + 20,
    top: y + 10,
    // Ensure tooltip stays within viewport bounds
    maxWidth: '200px',
    // Prevent flickering by using transform instead of position when near edges
    transform: `translateX(${x + 20 + 200 > window.innerWidth ? -220 : 0}px)`
  };
  
  return (
    <div 
      className="absolute z-20 bg-gray-900/90 backdrop-blur-sm p-2 rounded shadow-lg border border-gray-700 text-sm"
      style={tooltipStyle}
    >
      <div className="font-bold mb-1 text-base">{country.name}</div>
      {getTooltipContent()}
    </div>
  );
};
```