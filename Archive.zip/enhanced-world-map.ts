```typescript
// src/renderer/components/map/EnhancedWorldMap.tsx
import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';
import { MapRenderer } from './MapRenderer';
import { selectCountry } from '../../features/ui/uiSlice';
import { audioService } from '../../services/AudioService';
import { MapControls } from './MapControls';
import { CountryTooltip } from './CountryTooltip';

export const EnhancedWorldMap: React.FC = () => {
  const dispatch = useDispatch();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [mapRenderer, setMapRenderer] = useState<MapRenderer | null>(null);
  const [hoveredCountryId, setHoveredCountryId] = useState<string | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });
  
  const selectedCountryId = useSelector((state: RootState) => state.ui.selectedCountryId);
  const countries = useSelector((state: RootState) => state.world.countries);
  const mapMode = useSelector((state: RootState) => state.ui.mapMode);
  
  // Initialize map renderer on mount
  useEffect(() => {
    if (!mapContainerRef.current) return;
    
    // Create map renderer
    const renderer = new MapRenderer(mapContainerRef.current);
    
    // Set callbacks
    renderer.setOnCountrySelect((countryId) => {
      audioService.playSound('click');
      dispatch(selectCountry(countryId));
    });
    
    renderer.setOnCountryHover((countryId) => {
      setHoveredCountryId(countryId);
      
      // Play hover sound when hovering over a country
      if (countryId && hoveredCountryId !== countryId) {
        audioService.playSound('hover', 0.2);
      }
      
      // Update tooltip position
      if (countryId) {
        const containerRect = mapContainerRef.current?.getBoundingClientRect();
        if (containerRect) {
          // Get mouse position
          const x = containerRect.width / 2;
          const y = containerRect.height / 2;
          
          setTooltipPosition({ x, y });
        }
      }
    });
    
    // Store renderer
    setMapRenderer(renderer);
    
    // Load map
    renderer.loadMap(countries);
    
    // Clean up
    return () => {
      renderer.dispose();
    };
  }, [dispatch]);
  
  // Update selected country when it changes
  useEffect(() => {
    if (mapRenderer) {
      mapRenderer.selectCountry(selectedCountryId);
    }
  }, [selectedCountryId, mapRenderer]);
  
  // Update map mode when it changes
  useEffect(() => {
    if (mapRenderer) {
      mapRenderer.setMapMode(mapMode);
    }
  }, [mapMode, mapRenderer]);
  
  // Update map data when countries change
  useEffect(() => {
    if (mapRenderer && Object.keys(countries).length > 0) {
      mapRenderer.loadMap(countries);
    }
  }, [countries, mapRenderer]);
  
  // Update mouse position for tooltip
  const handleMouseMove = (e: React.MouseEvent) => {
    if (hoveredCountryId) {
      setTooltipPosition({
        x: e.clientX - mapContainerRef.current!.getBoundingClientRect().left,
        y: e.clientY - mapContainerRef.current!.getBoundingClientRect().top
      });
    }
  };
  
  return (
    <div 
      ref={mapContainerRef}
      className="w-full h-full relative"
      onMouseMove={handleMouseMove}
    >
      {/* Map Controls */}
      <MapControls />
      
      {/* Country Tooltip */}
      {hoveredCountryId && (
        <CountryTooltip 
          countryId={hoveredCountryId}
          x={tooltipPosition.x}
          y={tooltipPosition.y}
        />
      )}
    </div>
  );
};
```