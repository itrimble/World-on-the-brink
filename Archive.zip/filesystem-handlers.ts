```typescript
// src/main/ipc/fileSystemHandlers.ts
import { app, ipcMain } from 'electron';
import fs from 'fs';
import path from 'path';

// Define the save games directory
const getSaveGamesDir = () => {
  return path.join(app.getPath('userData'), 'savedGames');
};

// Ensure save games directory exists
const ensureSaveGamesDir = () => {
  const dir = getSaveGamesDir();
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
};

export const setupFileSystemHandlers = () => {
  // Save game
  ipcMain.handle('save-game', async (_, saveName: string, gameData: any) => {
    try {
      const saveDir = ensureSaveGamesDir();
      const savePath = path.join(saveDir, `${saveName}.json`);
      
      // Add metadata to save
      const saveData = {
        ...gameData,
        metadata: {
          version: app.getVersion(),
          timestamp: Date.now(),
          saveName
        }
      };
      
      // Write save file
      fs.writeFileSync(savePath, JSON.stringify(saveData, null, 2), 'utf-8');
      
      return { success: true, path: savePath };
    } catch (error) {
      console.error('Error saving game:', error);
      return { success: false, error: (error as Error).message };
    }
  });

  // Load game
  ipcMain.handle('load-game', async (_, saveName: string) => {
    try {
      const saveDir = getSaveGamesDir();
      const savePath = path.join(saveDir, `${saveName}.json`);
      
      if (!fs.existsSync(savePath)) {
        return { success: false, error: 'Save file not found.' };
      }
      
      const saveData = JSON.parse(fs.readFileSync(savePath, 'utf-8'));
      
      return { success: true, data: saveData };
    } catch (error) {
      console.error('Error loading game:', error);
      return { success: false, error: (error as Error).message };
    }
  });

  // List saved games
  ipcMain.handle('list-saved-games', async () => {
    try {
      const saveDir = ensureSaveGamesDir();
      const files = fs.readdirSync(saveDir).filter(file => file.endsWith('.json'));
      
      const savedGames = files.map(file => {
        const fullPath = path.join(saveDir, file);
        const stats = fs.statSync(fullPath);
        
        try {
          // Read metadata from save file
          const saveData = JSON.parse(fs.readFileSync(fullPath, 'utf-8'));
          const { metadata } = saveData;
          
          return {
            fileName: file,
            saveName: metadata?.saveName || path.basename(file, '.json'),
            timestamp: metadata?.timestamp || stats.mtime.getTime(),
            version: metadata?.version || 'unknown',
            lastModified: stats.mtime.toISOString()
          };
        } catch (error) {
          // If metadata can't be read, use file data
          return {
            fileName: file,
            saveName: path.basename(file, '.json'),
            timestamp: stats.mtime.getTime(),
            version: 'unknown',
            lastModified: stats.mtime.toISOString()
          };
        }
      });
      
      // Sort by most recent first
      savedGames.sort((a, b) => b.timestamp - a.timestamp);
      
      return { success: true, savedGames };
    } catch (error) {
      console.error('Error listing saved games:', error);
      return { success: false, error: (error as Error).message };
    }
  });

  // Delete saved game
  ipcMain.handle('delete-saved-game', async (_, saveName: string) => {
    try {
      const saveDir = getSaveGamesDir();
      const savePath = path.join(saveDir, `${saveName}.json`);
      
      if (!fs.existsSync(savePath)) {
        return { success: false, error: 'Save file not found.' };
      }
      
      fs.unlinkSync(savePath);
      
      return { success: true };
    } catch (error) {
      console.error('Error deleting saved game:', error);
      return { success: false, error: (error as Error).message };
    }
  });
};
```