```typescript
import React from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';

export const Dashboard: React.FC = () => {
  const currentTurn = useSelector((state: RootState) => state.game.currentTurn);
  const politicalCapital = useSelector((state: RootState) => state.player.politicalCapital);
  const tensionLevel = useSelector((state: RootState) => state.world.tensionLevel);
  const climateStability = useSelector((state: RootState) => state.world.climateStabilityIndex);
  const prestige = useSelector((state: RootState) => state.player.prestige);
  
  return (
    <div className="flex justify-between items-center bg-gray-800/80 rounded-lg p-3 shadow-lg backdrop-blur-sm text-sm">
      <div className="flex space-x-6">
        <div className="dashboard-item">
          <span className="font-semibold">Turn:</span> {currentTurn}
        </div>
        
        <div className="dashboard-item">
          <span className="font-semibold">Political Capital:</span> 
          <span className="text-green-400"> {politicalCapital}</span>
        </div>
        
        <div className="dashboard-item">
          <span className="font-semibold">Tension Level:</span>
          <span className={`
            ${tensionLevel < 30 ? 'text-green-400' : 
              tensionLevel < 60 ? 'text-yellow-400' : 
              'text-red-400'}
          `}> {tensionLevel}%</span>
        </div>
        
        <div className="dashboard-item">
          <span className="font-semibold">Climate Stability:</span>
          <span className={`
            ${climateStability > 70 ? 'text-green-400' : 
              climateStability > 40 ? 'text-yellow-400' : 
              'text-red-400'}
          `}> {climateStability}%</span>
        </div>
      </div>
      
      <div className="flex space-x-6">
        <div className="dashboard-item">
          <span className="font-semibold">Prestige:</span>
          <span className="text-blue-400"> {prestige}</span>
        </div>
        
        <div className="dashboard-item">
          <button className="bg-blue-700 hover:bg-blue-600 rounded px-2 py-1 text-xs">
            View Score
          </button>
        </div>
      </div>
    </div>
  );
};
```