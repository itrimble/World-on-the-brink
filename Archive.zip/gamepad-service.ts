```typescript
// src/renderer/services/GamepadService.ts
type GamepadButtonMapping = {
  confirm: number;
  cancel: number;
  menu: number;
  pause: number;
  up: number;
  down: number;
  left: number;
  right: number;
  nextTurn: number;
  mapMode: number;
  help: number;
  quickSave: number;
};

type ControllerEventType = 
  | 'button_press'
  | 'button_release'
  | 'axis_change'
  | 'controller_connected'
  | 'controller_disconnected';

interface ControllerEvent {
  type: ControllerEventType;
  button?: number;
  axis?: number;
  value?: number;
  controller: number;
}

type EventCallback = (event: ControllerEvent) => void;

class GamepadService {
  private gamepadSupported: boolean = false;
  private gamepads: Gamepad[] = [];
  private buttonStates: boolean[][] = [];
  private axisValues: number[][] = [];
  private eventListeners: Map<ControllerEventType, EventCallback[]> = new Map();
  private isRunning: boolean = false;
  private deadzone: number = 0.15;
  private sensitivity: number = 0.5;
  private buttonMapping: GamepadButtonMapping = {
    confirm: 0,      // A button
    cancel: 1,       // B button
    menu: 9,         // Start button
    pause: 8,        // Select button
    up: 12,          // D-pad up
    down: 13,        // D-pad down
    left: 14,        // D-pad left
    right: 15,       // D-pad right
    nextTurn: 7,     // Right trigger
    mapMode: 6,      // Left trigger
    help: 3,         // Y button
    quickSave: 2,    // X button
  };

  constructor() {
    // Check if the browser supports the Gamepad API
    this.gamepadSupported = 'getGamepads' in navigator;
    
    if (this.gamepadSupported) {
      // Set up event listeners for gamepad connection/disconnection
      window.addEventListener('gamepadconnected', this.onGamepadConnected.bind(this));
      window.addEventListener('gamepaddisconnected', this.onGamepadDisconnected.bind(this));
      
      // Initialize event listener maps
      this.eventListeners.set('button_press', []);
      this.eventListeners.set('button_release', []);
      this.eventListeners.set('axis_change', []);
      this.eventListeners.set('controller_connected', []);
      this.eventListeners.set('controller_disconnected', []);
    }
  }

  /**
   * Start monitoring gamepad inputs
   */
  public start(): void {
    if (!this.gamepadSupported || this.isRunning) return;
    
    this.isRunning = true;
    this.update();
  }

  /**
   * Stop monitoring gamepad inputs
   */
  public stop(): void {
    this.isRunning = false;
  }

  /**
   * Update loop for checking gamepad state
   */
  private update(): void {
    if (!this.isRunning) return;
    
    this.updateGamepadState();
    
    // Request next frame
    requestAnimationFrame(this.update.bind(this));
  }

  /**
   * Update the internal gamepad state and fire events
   */
  private updateGamepadState(): void {
    // Get the current gamepads
    const gamepads = navigator.getGamepads();
    
    // Update the state for each gamepad
    for (let i = 0; i < gamepads.length; i++) {
      const gamepad = gamepads[i];
      
      // Skip null gamepads (disconnected)
      if (!gamepad) continue;
      
      // Initialize state arrays if needed
      if (!this.buttonStates[i]) {
        this.buttonStates[i] = new Array(gamepad.buttons.length).fill(false);
      }
      
      if (!this.axisValues[i]) {
        this.axisValues[i] = new Array(gamepad.axes.length).fill(0);
      }
      
      // Check buttons
      for (let j = 0; j < gamepad.buttons.length; j++) {
        const button = gamepad.buttons[j];
        const isPressed = button.pressed || button.value > 0.5;
        
        // If state has changed
        if (isPressed !== this.buttonStates[i][j]) {
          // Update state
          this.buttonStates[i][j] = isPressed;
          
          // Fire event
          const eventType = isPressed ? 'button_press' : 'button_release';
          this.fireEvent({
            type: eventType,
            button: j,
            controller: i
          });
        }
      }
      
      // Check axes
      for (let j = 0; j < gamepad.axes.length; j++) {
        let value = gamepad.axes[j];
        
        // Apply deadzone
        if (Math.abs(value) < this.deadzone) {
          value = 0;
        } else {
          // Apply sensitivity
          const sign = value > 0 ? 1 : -1;
          value = sign * Math.pow(Math.abs(value), this.sensitivity);
        }
        
        // If value has changed significantly
        if (Math.abs(value - this.axisValues[i][j]) > 0.1) {
          // Update state
          this.axisValues[i][j] = value;
          
          // Fire event
          this.fireEvent({
            type: 'axis_change',
            axis: j,
            value,
            controller: i
          });
        }
      }
    }
  }

  /**
   * Handle gamepad connection
   */
  private onGamepadConnected(event: GamepadEvent): void {
    console.log(`Gamepad connected at index ${event.gamepad.index}: ${event.gamepad.id}`);
    
    // Update our internal gamepads array
    this.gamepads[event.gamepad.index] = event.gamepad;
    
    // Initialize button states array
    this.buttonStates[event.gamepad.index] = new Array(event.gamepad.buttons.length).fill(false);
    
    // Initialize axis values array
    this.axisValues[event.gamepad.index] = new Array(event.gamepad.axes.length).fill(0);
    
    // Fire event
    this.fireEvent({
      type: 'controller_connected',
      controller: event.gamepad.index
    });
    
    // Start monitoring if not already running
    if (!this.isRunning) {
      this.start();
    }
  }

  /**
   * Handle gamepad disconnection
   */
  private onGamepadDisconnected(event: GamepadEvent): void {
    console.log(`Gamepad disconnected from index ${event.gamepad.index}: ${event.gamepad.id}`);
    
    // Remove from our internal arrays
    delete this.gamepads[event.gamepad.index];
    delete this.buttonStates[event.gamepad.index];
    delete this.axisValues[event.gamepad.index];
    
    // Fire event
    this.fireEvent({
      type: 'controller_disconnected',
      controller: event.gamepad.index
    });
    
    // Stop if no gamepads left
    if (this.gamepads.filter(Boolean).length === 0) {
      this.stop();
    }
  }

  /**
   * Fire an event to all registered listeners
   */
  private fireEvent(event: ControllerEvent): void {
    const listeners = this.eventListeners.get(event.type) || [];
    
    for (const listener of listeners) {
      listener(event);
    }
  }

  /**
   * Add an event listener
   */
  public addEventListener(eventType: ControllerEventType, callback: EventCallback): void {
    if (!this.eventListeners.has(eventType)) {
      this.eventListeners.set(eventType, []);
    }
    
    this.eventListeners.get(eventType)!.push(callback);
  }

  /**
   * Remove an event listener
   */
  public removeEventListener(eventType: ControllerEventType, callback: EventCallback): void {
    if (!this.eventListeners.has(eventType)) return;
    
    const listeners = this.eventListeners.get(eventType)!;
    const index = listeners.indexOf(callback);
    
    if (index !== -1) {
      listeners.splice(index, 1);
    }
  }

  /**
   * Check if a button is currently pressed
   */
  public isButtonPressed(controllerIndex: number, button: number): boolean {
    return this.buttonStates[controllerIndex]?.[button] || false;
  }

  /**
   * Get the value of an axis
   */
  public getAxisValue(controllerIndex: number, axis: number): number {
    return this.axisValues[controllerIndex]?.[axis] || 0;
  }

  /**
   * Check if a mapped button is pressed
   */
  public isMappedButtonPressed(controllerIndex: number, mappedButton: keyof GamepadButtonMapping): boolean {
    const buttonIndex = this.buttonMapping[mappedButton];
    return this.isButtonPressed(controllerIndex, buttonIndex);
  }

  /**
   * Get the current controller button mapping
   */
  public getButtonMapping(): GamepadButtonMapping {
    return { ...this.buttonMapping };
  }

  /**
   * Set a new controller button mapping
   */
  public setButtonMapping(mapping: Partial<GamepadButtonMapping>): void {
    this.buttonMapping = {
      ...this.buttonMapping,
      ...mapping
    };
  }

  /**
   * Set the controller deadzone
   */
  public setDeadzone(deadzone: number): void {
    this.deadzone = Math.max(0, Math.min(1, deadzone));
  }

  /**
   * Set the controller sensitivity
   */
  public setSensitivity(sensitivity: number): void {
    this.sensitivity = Math.max(0.1, Math.min(2, sensitivity));
  }

  /**
   * Check if the gamepad API is supported
   */
  public isSupported(): boolean {
    return this.gamepadSupported;
  }

  /**
   * Check if any gamepad is connected
   */
  public hasGamepad(): boolean {
    return this.gamepads.some(Boolean);
  }

  /**
   * Get the number of connected gamepads
   */
  public getGamepadCount(): number {
    return this.gamepads.filter(Boolean).length;
  }
}

// Export singleton instance
export const gamepadService = new GamepadService();
```