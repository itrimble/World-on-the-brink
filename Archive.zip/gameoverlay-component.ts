```typescript
import React from 'react';

interface GameOverlayProps {
  children: React.ReactNode;
}

export const GameOverlay: React.FC<GameOverlayProps> = ({ children }) => {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm z-50">
      <div className="bg-gray-800 p-8 rounded-lg shadow-2xl max-w-2xl text-center">
        {children}
      </div>
    </div>
  );
};
```