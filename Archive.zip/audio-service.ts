```typescript
// src/renderer/services/AudioService.ts
class AudioService {
  private sounds: Map<string, HTMLAudioElement> = new Map();
  private music: HTMLAudioElement | null = null;
  private musicVolume: number = 0.7;
  private soundVolume: number = 0.8;
  private masterVolume: number = 1.0;
  private currentMusicTrack: string = '';
  private isMusicEnabled: boolean = true;
  private isSoundEnabled: boolean = true;

  constructor() {
    // Preload common sounds
    this.preloadSounds();
  }

  /**
   * Preload commonly used sounds
   */
  private preloadSounds(): void {
    const commonSounds = [
      'click',
      'hover',
      'alert',
      'success',
      'error',
      'transition'
    ];

    commonSounds.forEach(sound => {
      this.loadSound(sound, `audio/ui/${sound}.mp3`);
    });
  }

  /**
   * Load a sound effect
   * @param id Sound identifier
   * @param path Path to sound file
   */
  public loadSound(id: string, path: string): void {
    const audio = new Audio(path);
    audio.preload = 'auto';
    this.sounds.set(id, audio);
  }

  /**
   * Play a sound effect
   * @param id Sound identifier
   * @param volume Optional volume override (0-1)
   * @returns Promise that resolves when sound finishes playing
   */
  public playSound(id: string, volume?: number): Promise<void> {
    if (!this.isSoundEnabled) {
      return Promise.resolve();
    }

    const sound = this.sounds.get(id);
    if (!sound) {
      console.warn(`Sound not found: ${id}`);
      return Promise.resolve();
    }

    // Clone the audio to allow multiple instances of the same sound
    const soundInstance = sound.cloneNode() as HTMLAudioElement;
    soundInstance.volume = (volume !== undefined ? volume : this.soundVolume) * this.masterVolume;
    
    return new Promise((resolve) => {
      soundInstance.play();
      soundInstance.onended = () => resolve();
    });
  }

  /**
   * Load and play music track
   * @param id Music track identifier
   * @param path Path to music file
   * @param fadeIn Fade in duration in milliseconds
   */
  public playMusic(id: string, path: string, fadeIn: number = 1000): void {
    if (!this.isMusicEnabled) {
      return;
    }

    // Don't restart if already playing this track
    if (id === this.currentMusicTrack && this.music && !this.music.paused) {
      return;
    }

    this.currentMusicTrack = id;

    // If we have an existing track, fade it out
    if (this.music) {
      this.fadeOutMusic(500).then(() => {
        this.startNewMusicTrack(path, fadeIn);
      });
    } else {
      this.startNewMusicTrack(path, fadeIn);
    }
  }

  /**
   * Start playing a new music track
   * @param path Path to music file
   * @param fadeIn Fade in duration in milliseconds
   */
  private startNewMusicTrack(path: string, fadeIn: number): void {
    this.music = new Audio(path);
    this.music.loop = true;
    this.music.volume = 0;
    this.music.play();

    this.fadeInMusic(fadeIn);
  }

  /**
   * Fade in the current music track
   * @param duration Fade in duration in milliseconds
   */
  private fadeInMusic(duration: number): void {
    if (!this.music) return;

    const targetVolume = this.musicVolume * this.masterVolume;
    const startTime = performance.now();
    const music = this.music;

    const fadeStep = () => {
      const now = performance.now();
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);

      music.volume = progress * targetVolume;

      if (progress < 1) {
        requestAnimationFrame(fadeStep);
      }
    };

    requestAnimationFrame(fadeStep);
  }

  /**
   * Fade out the current music track
   * @param duration Fade out duration in milliseconds
   * @returns Promise that resolves when fadeout is complete
   */
  public fadeOutMusic(duration: number): Promise<void> {
    if (!this.music) return Promise.resolve();

    return new Promise((resolve) => {
      const startVolume = this.music.volume;
      const startTime = performance.now();
      const music = this.music;

      const fadeStep = () => {
        const now = performance.now();
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1);

        music.volume = startVolume * (1 - progress);

        if (progress < 1) {
          requestAnimationFrame(fadeStep);
        } else {
          music.pause();
          resolve();
        }
      };

      requestAnimationFrame(fadeStep);
    });
  }

  /**
   * Stop the current music track
   * @param fadeOut Fade out duration in milliseconds
   */
  public stopMusic(fadeOut: number = 500): Promise<void> {
    if (!this.music) return Promise.resolve();
    
    this.currentMusicTrack = '';
    return this.fadeOutMusic(fadeOut);
  }

  /**
   * Pause the current music track
   */
  public pauseMusic(): void {
    if (this.music) {
      this.music.pause();
    }
  }

  /**
   * Resume the current music track
   */
  public resumeMusic(): void {
    if (this.music && this.isMusicEnabled) {
      this.music.play();
    }
  }

  /**
   * Set master volume for all audio
   * @param volume Volume level (0-1)
   */
  public setMasterVolume(volume: number): void {
    this.masterVolume = Math.max(0, Math.min(1, volume));
    
    if (this.music) {
      this.music.volume = this.musicVolume * this.masterVolume;
    }
  }

  /**
   * Set volume for music
   * @param volume Volume level (0-1)
   */
  public setMusicVolume(volume: number): void {
    this.musicVolume = Math.max(0, Math.min(1, volume));
    
    if (this.music) {
      this.music.volume = this.musicVolume * this.masterVolume;
    }
  }

  /**
   * Set volume for sound effects
   * @param volume Volume level (0-1)
   */
  public setSoundVolume(volume: number): void {
    this.soundVolume = Math.max(0, Math.min(1, volume));
  }

  /**
   * Enable or disable music
   * @param enabled Whether music should be enabled
   */
  public enableMusic(enabled: boolean): void {
    this.isMusicEnabled = enabled;
    
    if (!enabled && this.music) {
      this.fadeOutMusic(500);
    } else if (enabled && this.music && this.currentMusicTrack) {
      this.music.play();
    }
  }

  /**
   * Enable or disable sound effects
   * @param enabled Whether sound effects should be enabled
   */
  public enableSound(enabled: boolean): void {
    this.isSoundEnabled = enabled;
  }

  /**
   * Play a spatial sound based on a position on the map
   * @param id Sound identifier
   * @param x X coordinate (0-1 from left to right)
   * @param y Y coordinate (0-1 from top to bottom)
   * @param maxDistance Maximum distance for full attenuation (0-1)
   */
  public playSpatialSound(id: string, x: number, y: number, maxDistance: number = 0.5): Promise<void> {
    if (!this.isSoundEnabled) {
      return Promise.resolve();
    }

    // Calculate distance from center (0.5, 0.5)
    const dx = x - 0.5;
    const dy = y - 0.5;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    // Calculate volume based on distance
    const distanceFactor = Math.max(0, 1 - distance / maxDistance);
    const volume = this.soundVolume * distanceFactor;
    
    // Don't play if too far away
    if (volume <= 0.01) {
      return Promise.resolve();
    }
    
    // Pan based on x position
    // Note: Web Audio API would be better for spatial audio,
    // but this is a simple approximation
    const sound = this.sounds.get(id);
    if (!sound) {
      console.warn(`Sound not found: ${id}`);
      return Promise.resolve();
    }
    
    // Play with calculated volume
    return this.playSound(id, volume);
  }
}

// Export singleton instance
export const audioService = new AudioService();
```