```typescript
// src/renderer/components/crisis/CrisisPanel.tsx
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Crisis, CrisisStage } from '../../../shared/types/crisis';
import { RootState } from '../../store';
import { Button } from '../common/Button';
import { crisisService } from '../../services/CrisisService';
import { audioService } from '../../services/AudioService';

interface CrisisPanelProps {
  crisis: Crisis;
  onEscalate: () => void;
  onBackDown: () => void;
  onClose?: () => void;
}

export const CrisisPanel: React.FC<CrisisPanelProps> = ({
  crisis,
  onEscalate,
  onBackDown,
  onClose
}) => {
  const dispatch = useDispatch();
  const playerFaction = useSelector((state: RootState) => state.player.faction);
  const isInitiator = crisis.initiator === playerFaction;
  const tensionLevel = useSelector((state: RootState) => state.world.tensionLevel);
  
  // Calculate prestige at stake
  const stageIndex = crisisService.getCrisisStageIndex(crisis.currentStage);
  const totalStages = crisisService.getTotalCrisisStages();
  const prestigeAtStake = Math.round(20 + (stageIndex * 10));
  
  // Get involved countries names (would come from actual country data in real implementation)
  const countriesInvolved = crisis.involvedCountries.join(', ');
  
  // Determine crisis description based on stage
  const getStageDescription = (stage: CrisisStage) => {
    return crisisService.getCrisisStageDescription(stage);
  };
  
  // Handle sound effects for buttons
  const handleEscalateClick = () => {
    audioService.playSound('crisis_button');
    onEscalate();
  };
  
  const handleBackDownClick = () => {
    audioService.playSound('crisis_retreat');
    onBackDown();
  };
  
  // Determine warning level based on stage
  const getWarningLevel = () => {
    if (stageIndex < 2) return 'low';
    if (stageIndex < 4) return 'medium';
    return 'high';
  };
  
  const warningLevel = getWarningLevel();
  
  return (
    <div className="bg-gray-900/95 border border-red-800 p-6 rounded-lg shadow-xl max-w-2xl w-full">
      <div className="mb-6">
        <div className="flex justify-between items-start">
          <h2 className="text-2xl font-bold text-red-500">
            CRISIS: {crisis.type.replace('-', ' ').toUpperCase()}
          </h2>
          
          {onClose && (
            <button
              className="text-gray-400 hover:text-white"
              onClick={onClose}
            >
              ✕
            </button>
          )}
        </div>
        
        <div className="flex items-center mt-2">
          <div className={`
            w-3 h-3 rounded-full mr-2
            ${warningLevel === 'low' ? 'bg-yellow-500' : 
              warningLevel === 'medium' ? 'bg-orange-500' : 
              'bg-red-500 animate-pulse'}
          `} />
          <span className="text-lg font-semibold">
            {getStageDescription(crisis.currentStage)}
          </span>
        </div>
      </div>
      
      <div className="mb-6">
        <div className="bg-gray-800 p-4 rounded border border-gray-700">
          <p className="mb-2">
            <span className="font-semibold">Countries Involved:</span> {countriesInvolved}
          </p>
          <p className="mb-2">
            <span className="font-semibold">Current Tension Level:</span> 
            <span className={`
              ml-2
              ${tensionLevel < 30 ? 'text-green-400' : 
                tensionLevel < 60 ? 'text-yellow-400' : 
                'text-red-400'}
            `}>
              {tensionLevel}%
            </span>
          </p>
          <p>
            <span className="font-semibold">Prestige at Stake:</span> 
            <span className="ml-2 text-blue-400">{prestigeAtStake} points</span>
          </p>
        </div>
      </div>
      
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-2">Crisis Assessment</h3>
        <div className="bg-gray-800 p-4 rounded border border-gray-700">
          <p className="mb-2">
            This crisis has reached a critical point. The next steps will significantly impact global stability and your geopolitical standing.
          </p>
          
          {stageIndex >= 3 && (
            <p className="text-yellow-400 mt-4">
              <span className="font-bold">WARNING:</span> At the current level of escalation, there is a risk of the situation spiraling out of control.
            </p>
          )}
          
          {stageIndex >= 5 && (
            <p className="text-red-400 mt-4 font-bold">
              EXTREME DANGER: Further escalation could lead to nuclear confrontation.
            </p>
          )}
        </div>
      </div>
      
      <div className="flex justify-between">
        <Button
          onClick={handleBackDownClick}
          variant="secondary"
          className="w-48"
        >
          Back Down{isInitiator ? '' : ' (-' + prestigeAtStake + ' Prestige)'}
        </Button>
        
        <Button
          onClick={handleEscalateClick}
          variant={stageIndex >= 4 ? "danger" : "primary"}
          className="w-48"
          disabled={crisis.currentStage === 'defcon-1'}
        >
          {crisis.currentStage === 'defcon-2' ? 'Launch Strike' : 'Escalate'}
        </Button>
      </div>
      
      {stageIndex >= 3 && (
        <div className="mt-6 text-center text-sm text-gray-500">
          Current accidental war risk: {Math.round((stageIndex - 2) * tensionLevel / 100)}%
        </div>
      )}
    </div>
  );
};
```