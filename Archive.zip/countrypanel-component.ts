```typescript
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';
import { closeCountryPanel } from '../../features/ui/uiSlice';
import { Country } from '../../shared/types/country';
import { Button } from '../common/Button';
import { PolicyMenu } from './PolicyMenu';

interface CountryPanelProps {
  countryId: string;
}

export const CountryPanel: React.FC<CountryPanelProps> = ({ countryId }) => {
  const dispatch = useDispatch();
  const [activeTab, setActiveTab] = useState<'overview' | 'diplomacy' | 'military' | 'economy'>('overview');
  const [showPolicyMenu, setShowPolicyMenu] = useState(false);
  
  // In a real implementation, this would come from the Redux store
  // This is just for demonstration purposes
  const country: Country = {
    id: countryId,
    name: 'Example Country',
    code: 'EX',
    government: {
      type: 'democracy',
      stability: 75,
      alignment: 'western'
    },
    economy: {
      gdp: 1200,
      growth: 2.5,
      development: 'medium'
    },
    military: {
      power: 50,
      spending: 45,
      nuclearStatus: 'none'
    },
    internal: {
      insurgencyLevel: 20,
      coupRisk: 15
    },
    relations: {
      usa: 85,
      ussr: 30
    }
  };
  
  return (
    <div className="bg-gray-800/90 backdrop-blur-sm rounded-lg shadow-lg h-full flex flex-col overflow-hidden">
      {/* Country Header */}
      <div className="p-4 bg-gray-700 flex justify-between items-center">
        <h2 className="text-xl font-bold">{country.name}</h2>
        <button 
          className="text-gray-400 hover:text-white"
          onClick={() => dispatch(closeCountryPanel())}
        >
          ✕
        </button>
      </div>
      
      {/* Tabs */}
      <div className="flex bg-gray-700">
        {(['overview', 'diplomacy', 'military', 'economy'] as const).map(tab => (
          <button
            key={tab}
            className={`
              px-4 py-2 text-sm
              ${activeTab === tab ? 'bg-gray-800 text-white' : 'text-gray-300 hover:bg-gray-600'}
            `}
            onClick={() => setActiveTab(tab)}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>
      
      {/* Content */}
      <div className="flex-grow p-4 overflow-y-auto">
        {activeTab === 'overview' && (
          <div>
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Government</h3>
              <p>Type: {country.government.type.charAt(0).toUpperCase() + country.government.type.slice(1)}</p>
              <p>Stability: {country.government.stability}%</p>
              <p>Alignment: {country.government.alignment.charAt(0).toUpperCase() + country.government.alignment.slice(1)}</p>
            </div>
            
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Internal Status</h3>
              <p>Insurgency Level: {country.internal.insurgencyLevel}%</p>
              <p>Coup Risk: {country.internal.coupRisk}%</p>
            </div>
            
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Relations</h3>
              <div className="flex items-center mb-1">
                <span className="w-20">USA:</span>
                <div className="h-2 bg-gray-600 flex-grow rounded">
                  <div 
                    className={`h-full rounded ${country.relations.usa > 50 ? 'bg-green-500' : 'bg-red-500'}`}
                    style={{ width: `${country.relations.usa}%` }}
                  />
                </div>
                <span className="ml-2">{country.relations.usa}</span>
              </div>
              <div className="flex items-center">
                <span className="w-20">USSR:</span>
                <div className="h-2 bg-gray-600 flex-grow rounded">
                  <div 
                    className={`h-full rounded ${country.relations.ussr > 50 ? 'bg-green-500' : 'bg-red-500'}`}
                    style={{ width: `${country.relations.ussr}%` }}
                  />
                </div>
                <span className="ml-2">{country.relations.ussr}</span>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'diplomacy' && (
          <div>
            <h3 className="text-lg font-semibold mb-2">Diplomatic Status</h3>
            <p>Diplomatic content goes here...</p>
          </div>
        )}
        
        {activeTab === 'military' && (
          <div>
            <h3 className="text-lg font-semibold mb-2">Military Power</h3>
            <p>Military Power: {country.military.power}</p>
            <p>Military Spending: {country.military.spending}% of GDP</p>
            <p>Nuclear Status: {country.military.nuclearStatus}</p>
          </div>
        )}
        
        {activeTab === 'economy' && (
          <div>
            <h3 className="text-lg font-semibold mb-2">Economic Data</h3>
            <p>GDP: ${country.economy.gdp} billion</p>
            <p>Growth Rate: {country.economy.growth}%</p>
            <p>Development Level: {country.economy.development}</p>
          </div>
        )}
      </div>
      
      {/* Action Buttons */}
      <div className="p-4 bg-gray-700">
        <Button
          onClick={() => setShowPolicyMenu(!showPolicyMenu)}
          variant="primary"
          fullWidth
        >
          Make Policy
        </Button>
        
        {showPolicyMenu && (
          <div className="absolute bottom-16 left-0 right-0 bg-gray-800 border border-gray-700 rounded-t-lg shadow-lg p-4">
            <PolicyMenu countryId={countryId} onClose={() => setShowPolicyMenu(false)} />
          </div>
        )}
      </div>
    </div>
  );
};
```