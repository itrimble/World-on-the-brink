# GeoPolitica Electron: Technical Architecture Blueprint

## System Overview

GeoPolitica Electron is a desktop-based geopolitical strategy game built on modern web technologies. The architecture employs a layered approach with clear separation of concerns, combining the strengths of Electron for cross-platform deployment, React for UI components, Redux for state management, and Three.js for map visualization.

```
┌─────────────────────────────────────────────────────────────┐
│                     Electron Container                      │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐ │
│ │   Renderer      │ │   Main Process  │ │  Shared Services │ │
│ │                 │ │                 │ │                  │ │
│ │  React + Redux  │ │  System Access  │ │  Save/Load      │ │
│ │  UI Components  │ │  File I/O       │ │  Configuration  │ │
│ │  Game Rendering │ │  Native Features│ │  Localization   │ │
│ └─────────────────┘ └─────────────────┘ └─────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Core Architectural Principles

1. **Modularity**: Components and systems are designed to be self-contained with clear interfaces
2. **State Isolation**: Game state is managed centrally through Redux with minimal local state
3. **Unidirectional Data Flow**: Actions → Reducers → State → UI
4. **Asynchronous Processing**: Game calculations run in background threads when possible
5. **Loose Coupling**: Systems interact through events and interfaces, not direct references

## Technology Stack

- **Application Framework**: Electron (latest stable)
- **UI Framework**: React 18+ with TypeScript
- **State Management**: Redux with Redux Toolkit
- **Rendering Engine**: Three.js for map visualization
- **Styling**: Tailwind CSS with custom design system
- **Audio**: HTML5 Audio API with custom wrapper
- **Storage**: Electron's IPC for file system access, IndexedDB for local cache
- **Testing**: Jest for unit tests, React Testing Library for components
- **Build/Package**: Electron Forge with Webpack

## Layered Architecture

### 1. Presentation Layer

```
┌───────────────────────────────────────────────────────────┐
│                     Presentation Layer                     │
├───────────────┬───────────────────────┬───────────────────┤
│ UI Components │ Map Visualization     │ Audio System      │
│               │                       │                   │
│ - Dashboard   │ - Three.js Renderer   │ - Sound Effects   │
│ - Panels      │ - Map Controls        │ - Music Player    │
│ - Menus       │ - Visual Effects      │ - Adaptive Audio  │
│ - Modals      │ - Country Selection   │ - Spatial Audio   │
└───────────────┴───────────────────────┴───────────────────┘
```

**Key Components:**
- **UI Component Library**: Reusable interface elements with consistent styling
- **Dashboard System**: Command center with specialized views (Intelligence, Diplomacy, Military)
- **Map Visualization**: Three.js-powered interactive world map with selection and highlighting
- **Audio Manager**: Background music and sound effects with spatial positioning for map events

### 2. Application Layer

```
┌───────────────────────────────────────────────────────────┐
│                    Application Layer                       │
├───────────────┬───────────────────────┬───────────────────┤
│ Game Logic    │ State Management      │ Event System      │
│               │                       │                   │
│ - Turn Proc.  │ - Redux Store         │ - Event Bus       │
│ - Crisis Sys. │ - Reducers/Actions    │ - Event Handlers  │
│ - AI Logic    │ - Selectors           │ - Subscriptions   │
│ - Gameplay    │ - Middleware          │ - Event History   │
└───────────────┴───────────────────────┴───────────────────┘
```

**Key Components:**
- **Game Logic Controllers**: Manage turn processing, crisis management, and core gameplay
- **Redux Store**: Central state management with specialized slices for different domains
- **Event System**: Publish/subscribe pattern for loose coupling between components
- **Game Loop**: Controls the flow of gameplay, turn advancement, and state updates

### 3. Domain Layer

```
┌───────────────────────────────────────────────────────────┐
│                      Domain Layer                          │
├───────────────┬───────────────────────┬───────────────────┤
│ Models        │ Services              │ Calculators       │
│               │                       │                   │
│ - Country     │ - Diplomacy Service   │ - Influence Calc  │
│ - Faction     │ - Military Service    │ - Stability Calc  │
│ - Policy      │ - Economy Service     │ - Resource Calc   │
│ - Crisis      │ - Intelligence Svc    │ - Risk Analysis   │
└───────────────┴───────────────────────┴───────────────────┘
```

**Key Components:**
- **Domain Models**: Core game entities (Country, Faction, Policy, Crisis)
- **Domain Services**: Business logic for game systems (Diplomacy, Military, Economy)
- **Calculation Engines**: Complex algorithms for game mechanics (Influence, Stability, Risk)
- **Validators**: Ensure game rules are followed and actions are valid

### 4. Infrastructure Layer

```
┌───────────────────────────────────────────────────────────┐
│                   Infrastructure Layer                     │
├───────────────┬───────────────────────┬───────────────────┤
│ Data Access   │ System Services       │ External Services │
│               │                       │                   │
│ - Save/Load   │ - File System         │ - Analytics       │
│ - Asset Mgmt  │ - User Preferences    │ - Cloud Save      │
│ - Data Cache  │ - Input Handling      │ - Updates         │
│ - Migration   │ - IPC Communication   │ - Achievement     │
└───────────────┴───────────────────────┴───────────────────┘
```

**Key Components:**
- **Data Access**: Game saving/loading, asset management, data migration
- **System Services**: Access to file system, preferences, input devices
- **External Services**: Analytics, cloud saves, update checking
- **Input Management**: Keyboard, mouse, and controller input handling

## Core System Designs

### Game State Management

The game state follows a Redux architecture with domain-specific slices:

```
┌─────────────────────┐
│     Redux Store     │
├─────────────┬───────┴─────────┬─────────────────┐
│ World Slice │ Player Slice    │ UI Slice        │
│             │                 │                 │
│ - Countries │ - Resources     │ - Selected      │
│ - Relations │ - Policies      │   Country       │
│ - Events    │ - Objectives    │ - Active Panel  │
│ - Crises    │ - Intelligence  │ - Notifications │
└─────────────┴─────────────────┴─────────────────┘
```

**State Management Flow:**
1. User initiates action (UI interaction)
2. Action is dispatched to Redux store
3. Middleware processes side effects (calculations, validations)
4. Reducers update state based on action
5. UI components re-render based on state changes

### Map Visualization System

Three.js provides the foundation for the interactive world map:

```
┌────────────────────────────────────────────┐
│              Map Renderer                  │
├────────────────┬───────────────────────────┤
│ Base Map Layer │ - Country geometries      │
│                │ - Ocean and terrain       │
├────────────────┼───────────────────────────┤
│ Data Layers    │ - Influence visualization │
│                │ - Relationship coloring   │
│                │ - Crisis indicators       │
├────────────────┼───────────────────────────┤
│ Interaction    │ - Selection               │
│                │ - Hover effects           │
│                │ - Zoom and pan            │
└────────────────┴───────────────────────────┘
```

**Map System Components:**
- **MapRenderer**: Core Three.js setup and rendering pipeline
- **CountryMeshManager**: Manages country geometries and selection
- **MapDataVisualizer**: Applies visual effects based on game state
- **MapInteractionController**: Handles user interaction with the map

### Turn Processing System

Turn advancement is a critical process managing game progression:

```
┌────────────────────────────────────────────┐
│            Turn Processor                  │
├────────────────┬───────────────────────────┤
│ Pre-Processing │ - Save current state      │
│                │ - Process player actions  │
├────────────────┼───────────────────────────┤
│ AI Processing  │ - Evaluate AI goals       │
│                │ - Generate AI actions     │
│                │ - Process AI decisions    │
├────────────────┼───────────────────────────┤
│ World Update   │ - Update relationships    │
│                │ - Process events          │
│                │ - Generate crises         │
├────────────────┼───────────────────────────┤
│ Post-Processing│ - Calculate new values    │
│                │ - Generate notifications  │
│                │ - Update game history     │
└────────────────┴───────────────────────────┘
```

**Key Processes:**
- Actions are collected during the player's turn
- Turn processor executes actions in predetermined order
- AI decision-making runs asynchronously for performance
- World state is updated with calculation results
- Events and notifications are generated for next turn

### Crisis Management System

The crisis system manages escalating tensions between powers:

```
┌────────────────────────────────────────────┐
│            Crisis System                   │
├────────────────┬───────────────────────────┤
│ Crisis         │ - Triggering conditions   │
│ Generation     │ - Escalation factors      │
│                │ - Impact assessment       │
├────────────────┼───────────────────────────┤
│ Crisis         │ - Escalation ladder       │
│ Progression    │ - Response options        │
│                │ - Risk calculation        │
├────────────────┼───────────────────────────┤
│ Resolution     │ - Prestige calculation    │
│                │ - Relationship impact     │
│                │ - Historical recording    │
└────────────────┴───────────────────────────┘
```

**Key Components:**
- **CrisisGenerator**: Creates crisis scenarios based on game conditions
- **CrisisEvaluator**: Determines escalation options and consequences
- **CrisisResolver**: Processes player decisions and calculates outcomes
- **CrisisVisualizer**: Presents crisis information and options to player

### AI System

The AI system drives non-player faction behavior:

```
┌────────────────────────────────────────────┐
│               AI System                    │
├────────────────┬───────────────────────────┤
│ Strategic      │ - Goal prioritization     │
│ Planning       │ - Threat assessment       │
│                │ - Opportunity evaluation  │
├────────────────┼───────────────────────────┤
│ Tactical       │ - Action selection        │
│ Decision       │ - Resource allocation     │
│                │ - Crisis management       │
├────────────────┼───────────────────────────┤
│ Personality    │ - Faction traits          │
│ Engine         │ - Historical tendencies   │
│                │ - Risk tolerance          │
└────────────────┴───────────────────────────┘
```

**Key Components:**
- **AIDirector**: Coordinates AI decision-making across factions
- **StrategyEvaluator**: Assesses global situation and prioritizes goals
- **ActionSelector**: Chooses specific actions to achieve strategic goals
- **PersonalityEngine**: Applies faction-specific behaviors and preferences

## Data Structures

### Core Game Entities

**Country:**
```typescript
interface Country {
  id: string;
  name: string;
  code: string;
  region: Region;
  government: GovernmentType;
  stability: number;
  economy: {
    gdp: number;
    growth: number;
    militarySpending: number;
    resourceWealth: number;
  };
  military: {
    personnel: number;
    power: number;
    nuclearStatus: NuclearStatus;
  };
  internal: {
    insurgencyLevel: number;
    coupRisk: number;
    civilUnrest: number;
  };
  relationships: Record<string, Relationship>;
}
```

**Faction:**
```typescript
interface Faction {
  id: string;
  name: string;
  leader: string;
  controlledCountries: string[];
  alignment: Alignment;
  personality: {
    aggression: number;
    trustworthiness: number;
    isolationism: number;
    riskTolerance: number;
  };
  specialAbilities: SpecialAbility[];
}
```

**Policy:**
```typescript
interface Policy {
  id: string;
  type: PolicyType;
  level: number;
  targetCountryId: string;
  sourceCountryId: string;
  cost: {
    politicalCapital: number;
    economicCost: number;
    militaryCost: number;
  };
  effects: PolicyEffect[];
  status: PolicyStatus;
  turnImplemented: number;
}
```

**Crisis:**
```typescript
interface Crisis {
  id: string;
  type: CrisisType;
  involvedCountries: string[];
  mainActor: string;
  targetActor: string;
  trigger: CrisisTrigger;
  currentStage: CrisisStage;
  escalationRisk: number;
  resolution?: CrisisResolution;
  prestige: {
    atStake: number;
    gained: Record<string, number>;
  };
}
```

## Communication Patterns

### Event-Driven Architecture

```
┌────────────┐  Dispatch   ┌────────────┐  Subscribe  ┌────────────┐
│            │ ───────────►│            │◄────────────│            │
│  Source    │             │   Event    │             │  Target    │
│ Component  │◄─────────── │    Bus     │ ───────────►│ Component  │
│            │  Notify     │            │  Broadcast  │            │
└────────────┘             └────────────┘             └────────────┘
```

**Event Types:**
- **GameStateEvents**: Turn advancement, win/loss conditions
- **UIEvents**: User interactions, selections, panel changes
- **WorldEvents**: Country changes, relationship updates, crises
- **SystemEvents**: Saving, loading, settings changes

### IPC Communication

For Electron's main and renderer process communication:

```
┌─────────────────┐                 ┌─────────────────┐
│  Renderer       │  IPC Channel    │  Main Process   │
│  Process        │◄───────────────►│                 │
│  (Game UI)      │                 │  (System Ops)   │
└─────────────────┘                 └─────────────────┘
```

**Key IPC Channels:**
- **file-system**: Save game, load game, export/import
- **system-info**: Hardware capabilities, screen resolution
- **user-preferences**: Settings storage and retrieval
- **native-features**: Notifications, menu handling, updates

## Performance Considerations

1. **Asynchronous Processing**:
   - Heavy calculations run in web workers
   - Turn processing executed in background threads
   - AI decision-making batched for efficiency

2. **Rendering Optimization**:
   - Three.js scene with optimized geometries
   - Level-of-detail system for map rendering
   - Instanced rendering for repeated elements
   - WebGL optimizations for map interactions

3. **State Management Efficiency**:
   - Selective state updates to prevent unnecessary renders
   - Memoized selectors for derived data
   - Batched actions for multi-step operations
   - Immutable data patterns with structural sharing

4. **Memory Management**:
   - Explicit resource cleanup for Three.js objects
   - Asset unloading when not in view
   - Memory monitoring and garbage collection hints
   - Texture atlasing for map elements

## Testing Strategy

1. **Unit Testing**:
   - Jest for business logic and calculations
   - Isolated component tests with React Testing Library
   - Mock services and data access

2. **Integration Testing**:
   - Component interaction tests
   - State management flows
   - Event processing sequences

3. **Performance Testing**:
   - Benchmark critical operations
   - Memory leak detection
   - Rendering performance profiling

4. **Playtest Automation**:
   - AI-driven game playthrough
   - Scenario validation
   - Balance testing

## Security Considerations

1. **Save Game Integrity**:
   - Checksum validation for save files
   - Sanitization of loaded data
   - Version compatibility checking

2. **Desktop Integration**:
   - Principle of least privilege for file system access
   - Secure IPC communication
   - Validation of external inputs

3. **Data Privacy**:
   - Optional telemetry with explicit consent
   - Local storage of preferences and saves
   - No unnecessary network connections

## Deployment Pipeline

```
┌───────────┐    ┌───────────┐    ┌───────────┐    ┌───────────┐
│           │    │           │    │           │    │           │
│  Build    ├───►│  Package  ├───►│  Sign     ├───►│ Distribute│
│           │    │           │    │           │    │           │
└───────────┘    └───────────┘    └───────────┘    └───────────┘
```

**Key Steps:**
1. **Build Process**: TypeScript compilation, asset bundling, optimization
2. **Packaging**: Electron Forge to create platform-specific packages
3. **Signing**: Code signing for macOS/Windows
4. **Distribution**: Platform-specific stores, direct download

## Conclusions

This architecture provides a solid foundation for GeoPolitica Electron with:

1. Clear separation of concerns through layered design
2. Scalable state management through Redux
3. High-performance visualization with Three.js
4. Modular components that can be developed independently
5. Cross-platform compatibility through Electron

The design prioritizes maintainability, performance, and extensibility, providing a technical foundation that can support the complex gameplay mechanics while remaining responsive and reliable across different platforms.