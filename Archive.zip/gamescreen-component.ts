```typescript
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../../store';
import { WorldMap } from '../../components/map/WorldMap';
import { Dashboard } from '../../components/dashboard/Dashboard';
import { GameOverlay } from '../../components/common/GameOverlay';
import { TurnControls } from '../../components/game/TurnControls';
import { CountryPanel } from '../../components/panels/CountryPanel';
import { setGameStatus } from '../../features/game/gameSlice';

export const GameScreen: React.FC = () => {
  const dispatch = useDispatch();
  const gameStatus = useSelector((state: RootState) => state.game.gameStatus);
  const currentYear = useSelector((state: RootState) => state.game.currentYear);
  const selectedCountryId = useSelector((state: RootState) => state.ui.selectedCountryId);
  
  return (
    <div className="relative w-full h-full">
      {/* World Map */}
      <div className="absolute inset-0">
        <WorldMap />
      </div>
      
      {/* Dashboard Overlay */}
      <div className="absolute top-0 left-0 right-0 p-4">
        <Dashboard />
      </div>
      
      {/* Year and Turn Controls */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
        <div className="bg-gray-800/80 p-2 rounded-lg shadow-lg">
          <div className="text-center mb-2">
            <span className="text-xl font-bold">{currentYear}</span>
          </div>
          <TurnControls />
        </div>
      </div>
      
      {/* Country Panel (when a country is selected) */}
      {selectedCountryId && (
        <div className="absolute right-4 top-20 bottom-20 w-80">
          <CountryPanel countryId={selectedCountryId} />
        </div>
      )}
      
      {/* Game Paused Overlay */}
      {gameStatus === 'paused' && (
        <GameOverlay>
          <h2 className="text-3xl mb-4">Game Paused</h2>
          <button 
            className="px-4 py-2 bg-blue-600 rounded"
            onClick={() => dispatch(setGameStatus('playing'))}
          >
            Resume
          </button>
        </GameOverlay>
      )}
      
      {/* Game Over Overlay */}
      {gameStatus === 'gameOver' && (
        <GameOverlay>
          <h2 className="text-3xl mb-4">Game Over</h2>
          <p className="mb-4">The year is {currentYear} and your game has concluded.</p>
          <button 
            className="px-4 py-2 bg-blue-600 rounded mr-2"
            onClick={() => dispatch(setGameStatus('menu'))}
          >
            Return to Menu
          </button>
          <button 
            className="px-4 py-2 bg-green-600 rounded"
            onClick={() => console.log('View results')}
          >
            View Results
          </button>
        </GameOverlay>
      )}
    </div>
  );
};
```