```typescript
// src/shared/types/game.ts
import { Country } from './country';
import { Crisis } from './crisis';
import { Policy } from './policy';

/**
 * Game historical event
 */
export interface HistoricalEvent {
  id: string;
  type: 'revolution' | 'coup' | 'finlandization' | 'treaty' | 'war';
  countries: string[];
  description: string;
  turn: number;
}

/**
 * Game world state
 */
export interface WorldState {
  countries: Record<string, Country>;
  tensionLevel: number;
  climateStabilityIndex: number;
  currentCrises: Crisis[];
  historicalEvents: HistoricalEvent[];
}

/**
 * Player state
 */
export interface PlayerState {
  faction: 'usa' | 'ussr';
  politicalCapital: number;
  prestige: number;
  militaryReserves: number;
  economicReserves: number;
  defcon: number;
  activePolicies: Policy[];
  diplomaticInfluence: Record<string, number>;
}

/**
 * Game save metadata
 */
export interface SaveMetadata {
  version: string;
  timestamp: number;
  saveName: string;
  createdAt: string;
}

/**
 * Complete game state for saving/loading
 */
export interface GameState {
  // Basic game state
  currentTurn: number;
  startYear: number;
  currentYear: number;
  endYear: number;
  gameDifficulty: 'beginner' | 'intermediate' | 'expert' | 'multipolar';
  gameMode: 'standard' | 'timed' | 'scenario';
  
  // World state
  world: WorldState;
  
  // Player state
  player: PlayerState;
  
  // Save metadata
  metadata: SaveMetadata;
}
```